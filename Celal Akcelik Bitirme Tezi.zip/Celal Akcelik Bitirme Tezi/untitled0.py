# -*- coding: utf-8 -*-
"""
Created on Thu Jun 13 19:16:56 2019

@author: celal
"""

import numpy as np
