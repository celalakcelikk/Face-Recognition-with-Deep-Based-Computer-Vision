# -*- coding: utf-8 -*-
"""
Created on Thu Jun 13 19:23:26 2019

@author: celal
"""

import cv2